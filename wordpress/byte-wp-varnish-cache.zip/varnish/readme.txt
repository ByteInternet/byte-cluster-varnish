=== Varnish Cache ===
Contributors: 42functions, Byte
Tags: varnish, cache
Tested up to: 4.1
Stable tag: 1.2.1

Varnish cache is a powerful extension which acts as a communication layer between Varnish and WordPress.

== Installation ==

1. Upload the folder 'varnish-cache' to the '/wp-content/plugins/' directory
2. Activate the plugin through the 'Plugins' menu in WordPress

== Changelog ==


= 1.2.1 =

* Fix: Prevented fatal error in term sibling loop
* Fix: Prevented fatal error in flush all (WPML)
* Fix: Repaired configuration mismatch for general policy flush

= 1.2.0 =

* New: Added 'cache_flush' filter, parameters: keys, cache instance
* New: Added 'cache_flush_all' filter, parameter: (bool)success, cache instance
* New: Added 'cache_form_display' action, parameter: Module
* New: Added 'cache_form_process' filter, parameter: data, Module
* New: Added experimental support for WPML (v 3.1.8.4)

= 1.1.0 =

* Fix: Removed redundent flag in 'Flush all' action
* Fix: Now flushes the additional supplied urls
* New: Added support to exclude pages from caching
* New: Added support to define expire headers
* New: Added support for flushing a particular url
* New: Added support for flushing an entire object structure
* New: Added Author flushing policy